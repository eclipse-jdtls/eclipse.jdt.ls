package jdt.ls.extension.with.dependency;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.jdt.internal.junit5.runner.JUnit5TestLoader;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;
import org.osgi.framework.ServiceReference;

public class Activator implements BundleActivator {

	public static final String PLUGIN_ID = "jdt.ls.extension";

	private static BundleContext context;

	static BundleContext getContext() {
		return context;
	}

	@Override
	public void start(BundleContext bundleContext) throws Exception {
		Activator.context = bundleContext;
		JUnit5TestLoader testLoader = new JUnit5TestLoader();
		testLoader.hashCode();
	}

	@Override
	public void stop(BundleContext bundleContext) throws Exception {
		Activator.context = null;
	}

	@SuppressWarnings("unchecked")
	public static <T> T acquireService(Class<T> serviceInterface) {
		ServiceReference<T> reference = (ServiceReference<T>) context.getServiceReference(serviceInterface.getName());
		if (reference == null) {
			return null;
		}
		T service = context.getService(reference);
		if (service != null) {
			context.ungetService(reference);
		}
		return service;
	}

	public static void log(IStatus status) {
		if (context != null) {
			Platform.getLog(context.getBundle()).log(status);
		}
	}

	public static void log(CoreException e) {
		log(e.getStatus());
	}

	public static void logError(String message) {
		if (context != null) {
			log(new Status(IStatus.ERROR, context.getBundle().getSymbolicName(), message));
		}
	}

	public static void logInfo(String message) {
		if (context != null) {
			log(new Status(IStatus.INFO, context.getBundle().getSymbolicName(), message));
		}
	}

	public static void logException(String message, Throwable ex) {
		if (context != null) {
			log(new Status(IStatus.ERROR, context.getBundle().getSymbolicName(), message, ex));
		}
	}
}
