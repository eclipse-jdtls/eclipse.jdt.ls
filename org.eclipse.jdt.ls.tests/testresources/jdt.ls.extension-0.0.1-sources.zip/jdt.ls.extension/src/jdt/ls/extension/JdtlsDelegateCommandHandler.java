package jdt.ls.extension;

import java.util.List;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.ls.core.internal.IDelegateCommandHandler;

public class JdtlsDelegateCommandHandler implements IDelegateCommandHandler {

	@Override
	public Object executeCommand(String commandId, List<Object> arguments, IProgressMonitor monitor) throws Exception {
		return "commandId:" + commandId;
	}

}
